import React, { useState, useEffect } from 'react';
import Scene from './components/Scene';
import UiOverlay from './components/UiOverlay';

const App: React.FC = () => {
  const [speed, setSpeed]     = useState(0);
  const [distance, setDistance] = useState(0);

  return (
    <div className="w-full h-screen overflow-hidden relative">
      <Scene
        setSpeed={setSpeed}
        setDistance={setDistance}
        isActive={true}
      />
      <UiOverlay speed={speed} distance={distance} />
    </div>
  );
};

export default App;