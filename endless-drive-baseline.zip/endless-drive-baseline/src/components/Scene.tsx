import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { setupPhysicsWorld } from '../lib/PhysicsWorld';
import { setupCameraRig } from '../lib/CameraRig';
import { setupCarControls } from '../lib/CarControls';

interface Props {
  setSpeed: (v: number) => void;
  setDistance: (v: number) => void;
  isActive: boolean;
}

const Scene: React.FC<Props> = ({ setSpeed, setDistance, isActive }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const requestRef = useRef<number>();
  const previousTimeRef = useRef<number>();

  useEffect(() => {
    /* ---------------- THREE BASICS ---------------- */
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87CEEB);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.shadowMap.enabled = true;

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 500);
    camera.position.set(0,3,5);

    /* Lights */
    const ambient = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambient);
    const dir = new THREE.DirectionalLight(0xffffff, 1);
    dir.position.set(10,10,10);
    dir.castShadow = true;
    scene.add(dir);

    /* Ground */
    const groundGeo = new THREE.PlaneGeometry(100,100);
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x1a472a, roughness:0.8 });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI/2;
    ground.receiveShadow = true;
    scene.add(ground);

    /* ---------------- PHYSICS ---------------- */
    const { world } = setupPhysicsWorld();

    /* Car + camera rig */
    const carPhysics = setupCarControls(world, scene);
    const cameraRig  = setupCameraRig(camera, carPhysics.body);

    /* Mount renderer */
    const handleResize = () => {
      if (!containerRef.current) return;
      const w = containerRef.current.clientWidth, h=containerRef.current.clientHeight;
      camera.aspect = w/h; camera.updateProjectionMatrix();
      renderer.setSize(w,h);
    };
    if (containerRef.current){
      containerRef.current.appendChild(renderer.domElement);
      handleResize();
    }
    window.addEventListener('resize', handleResize);

    /* Animation loop */
    let totalDistance = 0;
    const animate = (time:number)=>{
      if(previousTimeRef.current===undefined) previousTimeRef.current = time;
      const dt = Math.min((time-previousTimeRef.current)/1000,0.1);
      previousTimeRef.current = time;

      if(isActive){
        carPhysics.update();
        world.step(1/60, dt, 3);
        cameraRig.update(dt);

        /* speed & distance */
        const vel = carPhysics.body.velocity;
        const speed = Math.sqrt(vel.x*vel.x+vel.z*vel.z)*3.6;
        setSpeed(Math.round(speed));
        if(speed>0.1){
          totalDistance += (speed/3.6)*dt;
          setDistance(Math.round(totalDistance));
        }
      }

      renderer.render(scene,camera);
      requestRef.current = requestAnimationFrame(animate);
    };
    requestRef.current = requestAnimationFrame(animate);

    return ()=>{
      if(requestRef.current) cancelAnimationFrame(requestRef.current);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, [isActive, setSpeed, setDistance]);

  return <div ref={containerRef} className="w-full h-full"/>;
};

export default Scene;