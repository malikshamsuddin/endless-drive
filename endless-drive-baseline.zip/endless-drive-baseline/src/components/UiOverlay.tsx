import React from 'react';
import { Gauge, Map } from 'lucide-react';

interface Props {
  speed: number;
  distance: number;
}

const UiOverlay: React.FC<Props> = ({ speed, distance }) => {
  return (
    <div className="pointer-events-none absolute inset-0">
      <div className="absolute bottom-6 left-6 flex flex-col gap-4">
        <div className="bg-black/70 text-white backdrop-blur-sm rounded-lg p-4 flex items-center gap-3">
          <Gauge className="w-6 h-6 text-indigo-300"/>
          <div>
            <div className="text-xs tracking-wide text-indigo-300">SPEED</div>
            <div className="text-2xl font-bold">{speed} <span className="text-sm">km/h</span></div>
          </div>
        </div>
        <div className="bg-black/70 text-white backdrop-blur-sm rounded-lg p-4 flex items-center gap-3">
          <Map className="w-6 h-6 text-green-300"/>
          <div>
            <div className="text-xs tracking-wide text-green-300">DISTANCE</div>
            <div className="text-2xl font-bold">{distance} <span className="text-sm">m</span></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UiOverlay;